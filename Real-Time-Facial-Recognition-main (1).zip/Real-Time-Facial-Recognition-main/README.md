# Real-Time-Facial-Recognition

# We will be implementing facial recognition for attendance system
