if __name__=="__main__":
    root=Tk()
    obj=Face_Recognition(root)
    root.mainloop()